import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from data_utils import *

# 设置页面配置
st.set_page_config(
    page_title="长三角城市数据分析",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 加载自定义CSS
with open("assets/style.css", "r", encoding="utf-8") as f:
    st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

# 获取数据
all_years_data = get_all_years_data()
latest_data = all_years_data[-1]
city_types = get_city_scores_and_types()

# 创建侧边栏
st.sidebar.title("长三角城市数据")
st.sidebar.caption("2022-2024数据分析")

# 侧边栏导航
page = st.sidebar.radio(
    "选择页面",
    ["数据总览", "城市排名", "指标分析", "城市类型", "数据详情", "经济指标", "地区分布"]
)

# 创建指标名称映射
column_map = {}
for category in get_indicator_categories().values():
    for ind in category:
        column_map[ind["key"]] = ind["name"]

# 数据总览页面
if page == "数据总览":
    st.title("数据总览")
    
    # 年份选择器
    year_option = st.selectbox("选择年份", ["2022", "2023", "2024"], index=2)
    selected_year = int(year_option)
    
    # 获取选定年份的数据
    selected_data = next((data for data in all_years_data if data.year == selected_year), latest_data)
    
    # 关键指标卡片
    col1, col2, col3, col4 = st.columns(4)
    
    # 计算总GDP
    total_gdp = sum(city.综合GDP水平 for city in selected_data.cities if hasattr(city, '综合GDP水平'))
    col1.metric("GDP总量", f"{int(total_gdp)}亿元")
    
    # 计算总外资
    total_foreign_investment = sum(city.当年实际使用外资金额 for city in selected_data.cities)
    col2.metric("实际使用外资", f"{int(total_foreign_investment)}亿美元")
    
    # 计算总500强企业
    total_top500 = sum(city.全国制造业500强总部数 for city in selected_data.cities)
    col3.metric("制造业500强总部", f"{total_top500}个")
    
    # 计算总零售额
    total_retail = sum(city.社会消费品零售额 for city in selected_data.cities)
    col4.metric("社会消费品零售总额", f"{int(total_retail)}亿元")
    
    # GDP总量图表和指标概览
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("GDP总量（亿元）")
        st.caption("长三角地区GDP总量前10城市")
        
        # 按GDP排序并获取前10名城市
        top_gdp_cities = sorted(
                    [city for city in selected_data.cities if hasattr(city, '综合GDP水平')],
                    key=lambda x: x.综合GDP水平, 
                    reverse=True
                )[:10]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city.城市名 for city in top_gdp_cities],
            "GDP": [city.综合GDP水平 for city in top_gdp_cities]
        })
        
        # 创建条形图
        fig = px.bar(df, x="GDP", y="城市", orientation='h', 
                     color_discrete_sequence=['#1f77b4'])
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("指标概览")
        st.caption("长三角地区主要指标分布")
        
        # 指标选择
        categories = get_indicator_categories()
        category_option = st.selectbox("选择指标类别", list(categories.keys()))
        indicators = categories[category_option]
        
        indicator_option = st.selectbox(
            "选择具体指标", 
            [ind["name"] for ind in indicators],
            format_func=lambda x: x
        )
        
        # 获取选中的指标键
        selected_indicator_key = next(ind["key"] for ind in indicators if ind["name"] == indicator_option)
        
        # 按选中指标排序并获取前10名城市
        top_indicator_cities = sorted(
            selected_data.cities, 
            key=lambda x: getattr(x, selected_indicator_key), 
            reverse=True
        )[:10]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city.城市名 for city in top_indicator_cities],
            indicator_option: [getattr(city, selected_indicator_key) for city in top_indicator_cities]
        })
        
        # 创建条形图
        fig = px.bar(df, x=indicator_option, y="城市", orientation='h',
                     color_discrete_sequence=['#2ca02c'])
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    # 城市GDP排名表格
    st.subheader("城市GDP排名（前15）")
    st.caption("长三角地区城市GDP排名")
    
    # 按GDP排序并获取前15名城市
    top_cities = sorted(selected_data.cities, key=lambda x: x.综合GDP水平, reverse=True)[:15]
    
    # 创建DataFrame
    df = pd.DataFrame({
        "排名": range(1, len(top_cities) + 1),
        "城市": [city.城市名 for city in top_cities],
        "GDP (亿元)": [f"{city.综合GDP水平:,.0f}" for city in top_cities],
        "外资 (亿美元)": [f"{city.当年实际使用外资金额:,.2f}" for city in top_cities],
        "500强总部数": [city.全国制造业500强总部数 for city in top_cities],
        "零售额 (亿元)": [f"{city.社会消费品零售额:,.0f}" for city in top_cities]
    })
    
    st.dataframe(df, use_container_width=True)

# 城市排名页面
elif page == "城市排名":
    st.title("城市排名")
    
    # 指标类别选择
    tab1, tab2, tab3, tab4 = st.tabs(["经济指标", "创新指标", "基础设施", "环境指标"])
    
    with tab1:
        st.subheader("城市GDP排名")
        
        # 获取GDP数据
        gdp_data = get_indicator_data("综合GDP水平")
        latest_gdp = next((d for d in gdp_data if d["year"] == 2024), gdp_data[-1])
        
        # 排序并获取前20名
        top_gdp = sorted(latest_gdp["data"], key=lambda x: x["value"], reverse=True)[:20]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city["name"] for city in top_gdp],
            "GDP (亿元)": [city["value"] for city in top_gdp]
        })
        
        # 创建条形图
        fig = px.bar(df, x="GDP (亿元)", y="城市", orientation='h',
                     color_discrete_sequence=['#1f77b4'])
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("外资使用排名")
            
            # 获取外资数据
            foreign_investment_data = get_indicator_data("当年实际使用外资金额")
            latest_fi = next((d for d in foreign_investment_data if d["year"] == 2024), foreign_investment_data[-1])
            
            # 排序并获取前10名
            top_fi = sorted(latest_fi["data"], key=lambda x: x["value"], reverse=True)[:10]
            
            # 创建DataFrame
            df = pd.DataFrame({
                "排名": range(1, len(top_fi) + 1),
                "城市": [city["name"] for city in top_fi],
                "外资 (亿美元)": [f"{city['value']:.2f}" for city in top_fi]
            })
            
            st.dataframe(df, use_container_width=True)
        
        with col2:
            st.subheader("制造业500强总部排名")
            
            # 获取500强总部数据
            top500_data = get_indicator_data("全国制造业500强总部数")
            latest_top500 = next((d for d in top500_data if d["year"] == 2024), top500_data[-1])
            
            # 排序并获取前10名
            top_companies = sorted(latest_top500["data"], key=lambda x: x["value"], reverse=True)[:10]
            
            # 创建DataFrame
            df = pd.DataFrame({
                "排名": range(1, len(top_companies) + 1),
                "城市": [city["name"] for city in top_companies],
                "500强总部数": [int(city["value"]) for city in top_companies]
            })
            
            st.dataframe(df, use_container_width=True)
    
    with tab2:
        st.subheader("创新指标排名")
        
        # 创新指标选择
        innovation_indicators = get_indicator_categories()["创新指标"]
        indicator_option = st.selectbox(
            "选择创新指标", 
            [ind["name"] for ind in innovation_indicators],
            key="innovation_indicator"
        )
        
        # 获取选中的指标键
        selected_indicator_key = next(ind["key"] for ind in innovation_indicators if ind["name"] == indicator_option)
        
        # 获取指标数据
        indicator_data = get_indicator_data(selected_indicator_key)
        latest_indicator = next((d for d in indicator_data if d["year"] == 2024), indicator_data[-1])
        
        # 排序并获取前20名
        top_indicator = sorted(latest_indicator["data"], key=lambda x: x["value"], reverse=True)[:20]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city["name"] for city in top_indicator],
            indicator_option: [city["value"] for city in top_indicator]
        })
        
        # 创建条形图
        fig = px.bar(df, x=indicator_option, y="城市", orientation='h',
                     color_discrete_sequence=['#9467bd'])
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("基础设施指标排名")
        
        # 基础设施指标选择
        infra_indicators = get_indicator_categories()["基础设施指标"]
        indicator_option = st.selectbox(
            "选择基础设施指标", 
            [ind["name"] for ind in infra_indicators],
            key="infra_indicator"
        )
        
        # 获取选中的指标键
        selected_indicator_key = next(ind["key"] for ind in infra_indicators if ind["name"] == indicator_option)
        
        # 获取指标数据
        indicator_data = get_indicator_data(selected_indicator_key)
        latest_indicator = next((d for d in indicator_data if d["year"] == 2024), indicator_data[-1])
        
        # 排序并获取前20名
        top_indicator = sorted(latest_indicator["data"], key=lambda x: x["value"], reverse=True)[:20]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city["name"] for city in top_indicator],
            indicator_option: [city["value"] for city in top_indicator]
        })
        
        # 创建条形图
        fig = px.bar(df, x=indicator_option, y="城市", orientation='h',
                     color_discrete_sequence=['#ff7f0e'])
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.subheader("环境指标排名")
        
        # 环境指标选择
        env_indicators = get_indicator_categories()["环境指标"]
        indicator_option = st.selectbox(
            "选择环境指标", 
            [ind["name"] for ind in env_indicators],
            key="env_indicator"
        )
        
        # 获取选中的指标键
        selected_indicator_key = next(ind["key"] for ind in env_indicators if ind["name"] == indicator_option)
        
        # 获取指标数据
        indicator_data = get_indicator_data(selected_indicator_key)
        latest_indicator = next((d for d in indicator_data if d["year"] == 2024), indicator_data[-1])
        
        # 排序并获取前20名
        top_indicator = sorted(latest_indicator["data"], key=lambda x: x["value"], reverse=True)[:20]
        
        # 创建DataFrame
        df = pd.DataFrame({
            "城市": [city["name"] for city in top_indicator],
            indicator_option: [f"{city['value']*100:.1f}%" if "Rate" in selected_indicator_key else city["value"] for city in top_indicator]
        })
        
        # 创建条形图
        fig = px.bar(df, x=indicator_option, y="城市", orientation='h',
                     color_discrete_sequence=['#2ca02c'])
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)

# 指标分析页面
elif page == "指标分析":
    st.title("指标分析")
    
    st.subheader("指标对比分析")
    st.caption("选择指标进行城市对比分析")
    
    # 指标选择
    categories = get_indicator_categories()
    category_option = st.selectbox("选择指标类别", list(categories.keys()))
    indicators = categories[category_option]
    
    indicator_option = st.selectbox(
        "选择具体指标", 
        [ind["name"] for ind in indicators],
        format_func=lambda x: x
    )
    
    # 获取选中的指标键
    selected_indicator_key = next(ind["key"] for ind in indicators if ind["name"] == indicator_option)
    
    # 获取指标数据
    indicator_data = get_indicator_data(selected_indicator_key)
    latest_indicator = next((d for d in indicator_data if d["year"] == 2024), indicator_data[-1])
    
    # 排序并获取前15名
    top_indicator = sorted(latest_indicator["data"], key=lambda x: x["value"], reverse=True)[:15]
    
    # 创建DataFrame
    df = pd.DataFrame({
        "城市": [city["name"] for city in top_indicator],
        indicator_option: [city["value"] for city in top_indicator]
    })
    
    # 创建条形图
    fig = px.bar(df, x=indicator_option, y="城市", orientation='h',
                 color_discrete_sequence=['#1f77b4'])
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)
    
    # 显示指标类别
    col1, col2 = st.columns(2)
    
    for i, (category, inds) in enumerate(categories.items()):
        with col1 if i % 2 == 0 else col2:
            st.subheader(category)
            st.caption(f"包含{len(inds)}个指标")
            
            for ind in inds:
                st.markdown(f"• {ind['name']}")

# 城市类型页面
elif page == "城市类型":
    st.title("城市类型分析")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("城市类型分布")
        st.caption("长三角地区城市类型分布情况")
        
        # 获取城市类型数据
        type_data = get_city_type_data()
        
        # 创建饼图
        fig = px.pie(
            type_data, 
            values='count', 
            names='name',
            color='name',
            color_discrete_map={t["name"]: t["color"] for t in type_data},
            hole=0.3
        )
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("城市类型统计")
        st.caption("各类型城市数量及占比")
        
        # 获取城市类型数据
        type_data = get_city_type_data()
        total_cities = sum(t["count"] for t in type_data)
        
        # 显示每种类型的统计
        for t in type_data:
            st.markdown(f"### {t['name']}")
            st.markdown(f"{t['count']}个城市 ({int(t['count']/total_cities*100)}%)")
            
            # 创建进度条
            progress_html = f"""
            <div style="width:100%; background-color:#f0f0f0; height:10px; border-radius:5px; margin-bottom:20px;">
                <div style="width:{t['count']/total_cities*100}%; background-color:{t['color']}; height:10px; border-radius:5px;"></div>
            </div>
            """
            st.markdown(progress_html, unsafe_allow_html=True)
    
    st.subheader("城市类型详情")
    st.caption("长三角地区城市类型详情")
    
    # 过滤选项
    filter_text = st.text_input("搜索城市", "")
    filter_type = st.selectbox("选择城市类型", ["全部类型", "领先型", "成熟型", "生长型", "维持型", "衰退型"])
    
    # 过滤城市
    filtered_cities = [
        city for city in city_types
        if (filter_text.lower() in city["name"].lower() or not filter_text) and
           (filter_type == "全部类型" or city["cityType"] == filter_type)
    ]
    
    # 按得分排序
    sorted_cities = sorted(filtered_cities, key=lambda x: x["score"], reverse=True)
    
    # 创建DataFrame
    df = pd.DataFrame({
        "排名": range(1, len(sorted_cities) + 1),
        "城市": [city["name"] for city in sorted_cities],
        "城市类型": [city["cityType"] for city in sorted_cities],
        "得分": [f"{city['score']:.2f}" for city in sorted_cities]
    })
    
    # 设置城市类型的颜色
    def highlight_type(val):
        colors = {
            "领先型": "background-color: #4CAF50; color: white;",
            "成熟型": "background-color: #2196F3; color: white;",
            "生长型": "background-color: #FFC107;",
            "维持型": "background-color: #FF9800;",
            "衰退型": "background-color: #F44336; color: white;"
        }
        return colors.get(val, "")
    
    # 应用样式
    styled_df = df.style.applymap(highlight_type, subset=["城市类型"])
    
    st.dataframe(styled_df, use_container_width=True)

# 数据详情页面
elif page == "数据详情":
    st.title("数据详情")
    
    st.subheader("长三角城市综合数据")
    st.caption("41个城市各项指标详细数据")
    
    # 过滤选项
    filter_text = st.text_input("搜索城市", "")
    category_filter = st.selectbox("选择指标类别", ["全部类别"] + list(get_indicator_categories().keys()))
    
    # 获取最新年份的数据
    latest_data = all_years_data[-1]
    
    # 过滤城市
    filtered_cities = [
        city for city in latest_data.cities
        if filter_text.lower() in city.城市名.lower() or not filter_text
    ]
    
    # 按GDP排序
    sorted_cities = sorted(filtered_cities, key=lambda x: x.综合GDP水平, reverse=True)
    
    # 获取要显示的指标
    if category_filter == "全部类别":
        # 显示所有类别的第一个指标
        indicators_to_show = []
        for category in get_indicator_categories().values():
            indicators_to_show.append(category[0])
    else:
        # 显示选定类别的所有指标
        indicators_to_show = get_indicator_categories()[category_filter]
    
    # 创建DataFrame
    data = {
        "排名": range(1, len(sorted_cities) + 1),
        "城市": [city.城市名 for city in sorted_cities]
    }
    
    for indicator in indicators_to_show:
        key = indicator["key"]
        name = indicator["name"]
        
        # 格式化指标值
        if key in ["airQualityRate", "sewageTreatmentRate", "forestCoverageRate", "pollutantReductionRate"]:
            data[name] = [f"{getattr(city, key)*100:.1f}%" for city in sorted_cities]
        else:
            data[name] = [getattr(city, indicator["key"]) for city in sorted_cities]
    
    df = pd.DataFrame(data)
    
    # 分页
    page_size = 10
    total_pages = (len(df) + page_size - 1) // page_size
    
    col1, col2, col3 = st.columns([1, 3, 1])
    with col2:
        page_number = st.number_input("页码", min_value=1, max_value=total_pages, value=1)
    
    start_idx = (page_number - 1) * page_size
    end_idx = min(start_idx + page_size, len(df))
    
    st.dataframe(df.iloc[start_idx:end_idx], use_container_width=True)
    
    st.caption(f"显示 {len(df)} 个城市中的 {start_idx+1}-{end_idx} 个")


# 经济指标页面
elif page == "经济指标":
    st.title("经济指标")
    
    # 指标选择
    tab1, tab2, tab3, tab4 = st.tabs(["GDP", "投资", "进出口", "收入"])
    
    with tab1:
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("GDP增长率")
            st.caption("2022-2024年长三角地区GDP增长率变化")
            
            # 获取GDP数据
            gdp_data = []
            top_cities = ["上海", "南京", "杭州", "苏州", "宁波"]
            
            for year_data in all_years_data:
                for city in year_data.cities:
                    if city.城市名 in top_cities:
                        gdp_data.append({
                            "城市": city.城市名,
                            "年份": year_data.year,
                            "GDP (亿元)": city.综合GDP水平
                        })
            
            df = pd.DataFrame(gdp_data)
            
            # 创建折线图
            fig = px.line(
                df, 
                x="年份", 
                y="GDP (亿元)", 
                color="城市",
                markers=True,
                color_discrete_sequence=px.colors.qualitative.Set1
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("GDP总量对比")
            st.caption("2024年长三角地区GDP总量前10城市")
            
            # 获取最新年份的数据
            latest_data = all_years_data[-1]
            
            # 按GDP排序并获取前10名城市
            top_gdp_cities = sorted(latest_data.cities, key=lambda x: x.综合GDP水平, reverse=True)[:10]
            
            # 创建DataFrame
            df = pd.DataFrame({
                "城市": [city.城市名 for city in top_gdp_cities],
                "GDP (亿元)": [city.综合GDP水平 for city in top_gdp_cities]
            })
            
            # 创建条形图
            fig = px.bar(
                df, 
                x="城市", 
                y="GDP (亿元)",
                color_discrete_sequence=['#1f77b4']
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("GDP构成分析")
            st.caption("2024年长三角地区GDP产业结构")
            
            # 城市选择
            city_option = st.selectbox(
                "选择城市", 
                ["上海", "南京", "杭州", "合肥", "苏州"],
                key="gdp_structure_city"
            )
            
            # 模拟数据 - 实际应用中应从数据文件中读取
            city_data = {
                "上海": [
                    {"name": "第一产业", "value": 10},
                    {"name": "第二产业", "value": 35},
                    {"name": "第三产业", "value": 55},
                ],
                "南京": [
                    {"name": "第一产业", "value": 15},
                    {"name": "第二产业", "value": 40},
                    {"name": "第三产业", "value": 45},
                ],
                "杭州": [
                    {"name": "第一产业", "value": 12},
                    {"name": "第二产业", "value": 38},
                    {"name": "第三产业", "value": 50},
                ],
                "合肥": [
                    {"name": "第一产业", "value": 18},
                    {"name": "第二产业", "value": 45},
                    {"name": "第三产业", "value": 37},
                ],
                "苏州": [
                    {"name": "第一产业", "value": 8},
                    {"name": "第二产业", "value": 52},
                    {"name": "第三产业", "value": 40},
                ],
            }
            
            # 创建饼图
            fig = px.pie(
                city_data[city_option], 
                values='value', 
                names='name',
                color_discrete_sequence=px.colors.qualitative.Set2,
                hole=0.4
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("城市经济活力指数")
            st.caption("2024年长三角地区城市经济活力")
            
            # 模拟数据
            vitality_data = [
                {"city": "上海", "score": 92},
                {"city": "杭州", "score": 88},
                {"city": "南京", "score": 85},
                {"city": "苏州", "score": 84},
                {"city": "宁波", "score": 81},
            ]
            
            # 显示活力指数
            for item in vitality_data:
                st.markdown(f"### {item['city']}: {item['score']}")
                st.progress(item["score"] / 100)
    
    with tab2:
        st.subheader("投资指标分析")
        # 这里可以添加投资相关的图表和数据
        st.info("投资指标分析功能正在开发中...")
    
    with tab3:
        st.subheader("进出口指标分析")
        # 这里可以添加进出口相关的图表和数据
        st.info("进出口指标分析功能正在开发中...")
    
    with tab4:
        st.subheader("收入指标分析")
        # 这里可以添加收入相关的图表和数据
        st.info("收入指标分析功能正在开发中...")

# 地区分布页面
elif page == "地区分布":
    st.title("地区分布")
    
    st.subheader("长三角地区GDP分布")
    st.caption("2024年长三角地区GDP地理分布")
    
    # 指标选择
    indicator = st.selectbox("选择指标", ["GDP", "人口", "收入", "投资"])
    
    # 地图占位符
    st.markdown("""
    <div style="height: 400px; display: flex; align-items: center; justify-content: center; border: 1px solid #ddd; border-radius: 5px; background-color: #f9f9f9;">
        <div style="text-align: center;">
            <p>此处将显示长三角地区地图</p>
            <p style="font-size: 14px;">显示指标: {}</p>
        </div>
    </div>
    """.format(indicator), unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("省份GDP对比")
        st.caption("2024年长三角各省GDP对比")
        
        # 模拟数据
        province_data = [
            {"name": "上海市", "value": 4500},
            {"name": "江苏省", "value": 12000},
            {"name": "浙江省", "value": 7500},
            {"name": "安徽省", "value": 4200},
        ]
        
        # 创建条形图
        fig = px.bar(
            province_data, 
            x="name", 
            y="value",
            labels={"name": "省份", "value": "GDP (亿元)"},
            color_discrete_sequence=['#1f77b4']
        )
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("城市群GDP对比")
        st.caption("2024年长三角各城市群GDP对比")
        
        # 模拟数据
        city_group_data = [
            {"name": "上海都市圈", "value": 7800},
            {"name": "南京都市圈", "value": 5200},
            {"name": "杭州都市圈", "value": 4800},
            {"name": "合肥都市圈", "value": 2500},
            {"name": "苏锡常都市圈", "value": 3400},
        ]
        
        # 创建条形图
        fig = px.bar(
            city_group_data, 
            x="name", 
            y="value",
            labels={"name": "城市群", "value": "GDP (亿元)"},
            color_discrete_sequence=['#2ca02c']
        )
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)

# 添加页脚
st.sidebar.markdown("---")
st.sidebar.caption("数据更新时间: 2024年")