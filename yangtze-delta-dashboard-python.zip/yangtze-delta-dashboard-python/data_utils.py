import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional

# 城市数据结构
class CityData:
    # 修改属性名以匹配Excel列名
    城市名: str
    综合GDP水平: float
    当年实际使用外资金额: float
    全国制造业500强总部数: int
    银行总行分行数: int
    社会消费品零售额: float
    财政科技支出额: float
    双一流建设学科数量: int
    合作发明专利申请数量: int
    从事科技活动人员数量: int
    新基建发展水平: float
    机场客货运量: float
    铁路班次数量: int
    互联网用户数: int
    空气质量优良天数比率: float
    污水处理率: float
    森林覆盖率: float
    污染物排放强度降低率: float
    
    def __init__(self, data_dict: Dict[str, Any]):
        # 不再转换键为小写，保持原样
        for attr, type_ in self.__annotations__.items():
            if type_ in (int, float):
                setattr(self, attr, 0)
            else:
                setattr(self, attr, None)
                
        # 设置属性值
        # 设置属性值，确保列名完全匹配
        for key, value in data_dict.items():
            if hasattr(self, key):
                # 处理空值
                if pd.isna(value):
                    if isinstance(getattr(self, key), (int, float)):
                        setattr(self, key, 0)
                    else:
                        setattr(self, key, None)
                else:
                    setattr(self, key, value)

# 年度数据结构
class YearData:
    year: int
    cities: List[CityData]
    
    def __init__(self, year: int, cities: List[CityData]):
        self.year = year
        self.cities = cities

# 实际城市数据 - 完整的41个城市数据
# 添加Excel文件路径常量
DATA_FILE = "长三角2022-2024指标数据.xlsx"

# 修改get_actual_city_data函数
def get_actual_city_data(year):
    # 根据年份选择对应的Sheet
    sheet_name = f"{year}年数据"
    try:
        # 读取Excel文件，不转换列名
        df = pd.read_excel(DATA_FILE, sheet_name=sheet_name)
        
        # 验证数据是否为空
        if df.empty:
            raise ValueError(f"Excel文件 {sheet_name} 工作表为空")
            
        # 处理百分比数据
        for col in df.columns:
            if ('率' in col or '比率' in col) and df[col].dtype == 'object':
                # 移除百分号并转换为小数
                df[col] = df[col].astype(str).str.replace('%', '').astype(float) / 100.0
        
        # 填充数值列的None值为0
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(0)
                
        # 转换为字典列表
        return df.to_dict('records')
    except Exception as e:
        raise ValueError(f"加载 {year} 年数据失败: {str(e)}")

# 修改parse_data_file函数
def parse_data_file(year: int) -> YearData:
    """解析指定年份的数据文件"""
    try:
        city_data = get_actual_city_data(year)
        cities = [CityData(city) for city in city_data]
        
        # 验证数据是否加载成功
        if not cities:
            raise ValueError(f"{year}年数据为空")
            
        return YearData(year, cities)
    except Exception as e:
        raise ValueError(f"解析 {year} 年数据失败: {str(e)}")

# 修改get_all_years_data函数
def get_all_years_data() -> List[YearData]:
    """获取所有年份的数据"""
    years = [2022, 2023, 2024]
    result = []
    
    for year in years:
        year_data = parse_data_file(year)
        result.append(year_data)
        
            
    return result

# 城市类型数据 - 完整的41个城市类型数据
def get_city_scores_and_types():
    return [
        {"name": "上海", "score": 1, "cityType": "领先型"},
        {"name": "杭州", "score": 0.95, "cityType": "领先型"},
        {"name": "无锡", "score": 0.9, "cityType": "成熟型"},
        {"name": "苏州", "score": 0.92, "cityType": "领先型"},
        {"name": "宁波", "score": 0.88, "cityType": "成熟型"},
        {"name": "南京", "score": 0.89, "cityType": "成熟型"},
        {"name": "常州", "score": 0.85, "cityType": "生长型"},
        {"name": "绍兴", "score": 0.84, "cityType": "生长型"},
        {"name": "南通", "score": 0.87, "cityType": "成熟型"},
        {"name": "合肥", "score": 0.86, "cityType": "成熟型"},
        {"name": "嘉兴", "score": 0.83, "cityType": "生长型"},
        {"name": "徐州", "score": 0.82, "cityType": "生长型"},
        {"name": "镇江", "score": 0.81, "cityType": "生长型"},
        {"name": "扬州", "score": 0.8, "cityType": "生长型"},
        {"name": "温州", "score": 0.79, "cityType": "生长型"},
        {"name": "金华", "score": 0.78, "cityType": "生长型"},
        {"name": "台州", "score": 0.77, "cityType": "生长型"},
        {"name": "泰州", "score": 0.76, "cityType": "生长型"},
        {"name": "湖州", "score": 0.75, "cityType": "生长型"},
        {"name": "芜湖", "score": 0.74, "cityType": "生长型"},
        {"name": "盐城", "score": 0.73, "cityType": "生长型"},
        {"name": "马鞍山", "score": 0.65, "cityType": "维持型"},
        {"name": "舟山", "score": 0.45, "cityType": "衰退型"},
        {"name": "淮安", "score": 0.64, "cityType": "维持型"},
        {"name": "丽水", "score": 0.44, "cityType": "衰退型"},
        {"name": "铜陵", "score": 0.43, "cityType": "衰退型"},
        {"name": "连云港", "score": 0.63, "cityType": "维持型"},
        {"name": "蚌埠", "score": 0.62, "cityType": "维持型"},
        {"name": "宿迁", "score": 0.61, "cityType": "维持型"},
        {"name": "衢州", "score": 0.42, "cityType": "衰退型"},
        {"name": "滁州", "score": 0.6, "cityType": "维持型"},
        {"name": "宣城", "score": 0.41, "cityType": "衰退型"},
        {"name": "安庆", "score": 0.59, "cityType": "维持型"},
        {"name": "黄山", "score": 0.4, "cityType": "衰退型"},
        {"name": "淮北", "score": 0.39, "cityType": "衰退型"},
        {"name": "阜阳", "score": 0.58, "cityType": "维持型"},
        {"name": "宿州", "score": 0.38, "cityType": "衰退型"},
        {"name": "亳州", "score": 0.37, "cityType": "衰退型"},
        {"name": "池州", "score": 0.36, "cityType": "衰退型"},
        {"name": "淮南", "score": 0.35, "cityType": "衰退型"},
        {"name": "六安", "score": 0.34, "cityType": "衰退型"},
    ]

# 解析数据文件
#def parse_data_file(year):
    #city_data = get_actual_city_data()
    # 为不同年份生成略有差异的数据
    #if year < 2024:
        #factor = 0.95 if year == 2023 else 0.9
        #for city in city_data:
            #for key, value in city.items():
                #if key != "name" and isinstance(value, (int, float)):
                    #city[key] = value * factor
    
    #cities = [CityData(city) for city in city_data]
    #return YearData(year, cities)

# 获取所有年份的数据
#def get_all_years_data():
    #years = [2022, 2023, 2024]
    #return [parse_data_file(year) for year in years]

# 获取特定指标的所有城市数据
def get_indicator_data(indicator):
    all_data = get_all_years_data()
    
    result = []
    for year_data in all_data:
        data = []
        for city in year_data.cities:
            data.append({
                "name": city.城市名,
                "value": getattr(city, indicator)
            })
        result.append({
            "year": year_data.year,
            "data": data
        })
    
    return result

# 获取特定城市的所有年份数据
def get_city_data(city_name):
    all_data = get_all_years_data()
    
    city_data = []
    for year_data in all_data:
        for city in year_data.cities:
            if city.城市名 == city_name:
                data = {"year": year_data.year}
                for key, value in vars(city).items():
                    data[key] = value
                city_data.append(data)
                break
    
    return {"name": city_name, "data": city_data}

# 获取所有城市名称
def get_all_city_names():
    data = parse_data_file(2024)
    return [city.城市名 for city in data.cities]

# 按省份分组城市
def group_cities_by_province(cities=None):
    if cities is None:
        cities = get_all_city_names()
        
    province_map = {
        "上海市": [],
        "江苏省": [],
        "浙江省": [],
        "安徽省": [],
    }
    
    for city in cities:
        if city == "上海":
            province_map["上海市"].append(city)
        elif city in ["南京", "无锡", "常州", "苏州", "南通", "盐城", "扬州", "镇江", "泰州", "徐州", "连云港", "淮安", "宿迁"]:
            province_map["江苏省"].append(city)
        elif city in ["杭州", "宁波", "温州", "嘉兴", "湖州", "绍兴", "金华", "衢州", "舟山", "台州", "丽水"]:
            province_map["浙江省"].append(city)
        else:
            province_map["安徽省"].append(city)
    
    return province_map

# 获取指标分类
def get_indicator_categories():
    return {
        "经济指标": [
            {"name": "综合GDP水平（亿元）", "key": "综合GDP水平"},
            {"name": "当年实际使用外资金额（亿美元）", "key": "当年实际使用外资金额"},
            {"name": "社会消费品零售额（亿元）", "key": "社会消费品零售额"},
        ],
        "创新指标": [
            {"name": "全国制造业500强总部数", "key": "全国制造业500强总部数"},
            {"name": "财政科技支出额（亿元）", "key": "财政科技支出额"},
            {"name": "双一流建设学科数量", "key": "双一流建设学科数量"},
            {"name": "合作发明专利申请数量", "key": "合作发明专利申请数量"},
            {"name": "从事科技活动人员数量", "key": "从事科技活动人员数量"},
            {"name": "新基建发展水平（1-100）", "key": "新基建发展水平"},
        ],
        "基础设施指标": [
            {"name": "银行总行分行数", "key": "银行总行分行数"},
            {"name": "机场客货运量（万人次/万吨）", "key": "机场客货运量"},
            {"name": "铁路班次数量（日班次）", "key": "铁路班次数量"},
            {"name": "互联网用户数（万人）", "key": "互联网用户数"},
        ],
        "环境指标": [
            {"name": "空气质量优良天数比率", "key": "空气质量优良天数比率"},
            {"name": "污水处理率", "key": "污水处理率"},
            {"name": "森林覆盖率", "key": "森林覆盖率"},
            {"name": "污染物排放强度降低率", "key": "污染物排放强度降低率"},
        ],
    }

# 获取城市类型数据
def get_city_type_data():
    city_types = get_city_scores_and_types()
    
    type_counts = {}
    for city in city_types:
        city_type = city["cityType"]
        if city_type not in type_counts:
            type_counts[city_type] = 0
        type_counts[city_type] += 1
    
    colors = {
        "领先型": "#4CAF50",
        "成熟型": "#2196F3",
        "生长型": "#FFC107",
        "维持型": "#FF9800",
        "衰退型": "#F44336",
    }
    
    result = []
    for city_type, count in type_counts.items():
        result.append({
            "name": city_type,
            "count": count,
            "color": colors.get(city_type, "#999999")
        })
    
    return result

# 将数据转换为DataFrame
def convert_to_dataframe(data):
    if isinstance(data, YearData):
        return pd.DataFrame([vars(city) for city in data.cities])
    return pd.DataFrame(data)
